 spark-submit target/JavaSessionize-1.0-SNAPSHOT.jar  --class com.hadooparchitecturebook.clickstream.JavaSessionize local hdfs:///etl/BI/casualcyclist/clicks/deduplogs/year=2014/month=10/day=10 hdfs:///etl/BI/casualcyclist/clicks/sessionizedlogs/year=2014/month=10/day=10

