oozie job -oozie http://localhost:11000/oozie -config job.properties  -run
