#!/bin/sh

flume-ng agent -n client --conf . -f client.conf 
