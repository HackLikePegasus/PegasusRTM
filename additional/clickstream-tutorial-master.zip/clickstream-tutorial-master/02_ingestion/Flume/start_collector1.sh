#!/bin/sh

flume-ng agent -n collector1 --conf . -f collector1.conf
