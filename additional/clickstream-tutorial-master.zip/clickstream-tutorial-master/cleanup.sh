#!/bin/bash
sudo -u hdfs hadoop fs -rmr /etl
sudo -u hdfs hadoop fs -rmr /data
